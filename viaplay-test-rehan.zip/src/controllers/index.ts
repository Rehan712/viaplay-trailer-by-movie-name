export * from './ping.controller';
export * from './movie.controller';
